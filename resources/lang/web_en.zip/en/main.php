<?php

return [

    'user' => 'User',
    'provider' => 'Provider',
    'service' => 'Service'

];